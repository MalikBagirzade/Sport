﻿using System.Collections.Generic;

namespace Sport_Master.Models
{
    public interface IMembershipService
    {
        IEnumerable<Membership> GetAllMemberships();
        Membership GetMembershipById(int id);
        void AddMembership(Membership membership);
        void UpdateMembership(Membership membership);
        void DeleteMembership(int id);
    }
}
