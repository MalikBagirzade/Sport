﻿using System.Collections.Generic;

namespace Sport_Master.Models
{
    public interface IInstructorService
    {
        IEnumerable<Instructor> GetAllInstructors();
        Instructor GetInstructorById(int id);
        void AddInstructor(Instructor instructor);
        void UpdateInstructor(Instructor instructor);
        void DeleteInstructor(int id);
    }
}
