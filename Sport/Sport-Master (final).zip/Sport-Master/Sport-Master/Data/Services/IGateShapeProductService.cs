﻿using Sport_Master.Models;
using System.Collections.Generic;

namespace Sport_Master.Services
{
    public interface IGateShapeProductService
    {
        IEnumerable<GateShapeProduct> GetAllProducts();
        GateShapeProduct GetProductById(int id);
        void AddProduct(GateShapeProduct product);
        void UpdateProduct(GateShapeProduct product);
        void DeleteProduct(int id);
    }
}
