﻿using Microsoft.AspNetCore.Mvc;
using Sport_Master.Models;
using System.Linq;

namespace Sport_Master.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        public AccountController(AppDbContext context)
        {
            _context = context;
        }

        // Login
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = _context.Users.SingleOrDefault(u => u.UserName == model.UserName && u.Password == model.Password);
                if (user != null)
                {
                    // Login successful, redirect to home page
                    return RedirectToAction("Index", "Home");
                }
                ModelState.AddModelError("", "Invalid username or password");
            }
            return View(model);
        }

        // Register
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var existingUser = _context.Users.SingleOrDefault(u => u.UserName == model.UserName || u.Email == model.Email);
                if (existingUser == null)
                {
                    var newUser = new User
                    {
                        UserName = model.UserName,
                        Email = model.Email,
                        Password = model.Password,
                        FullName = model.FullName,
                        DateOfBirth = model.DateOfBirth
                    };

                    _context.Users.Add(newUser);
                    _context.SaveChanges();

                    // Redirect to register completed page
                    return RedirectToAction("RegisterCompleted");
                }
                ModelState.AddModelError("", "Username or email already exists");
            }
            return View(model);
        }

        // RegisterCompleted
        public IActionResult RegisterCompleted()
        {
            return View();
        }

        // AccessDenied
        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}
